# NIFTY Free / Delayed Intraday Signal Desk

No Dhan, no broker login, no order placement. Built with Streamlit + yfinance.

## Data limitations
- Uses Yahoo Finance public data via `yfinance`; availability and delay are provider-controlled.
- Yahoo's NIFTY options page states options data is delayed by 15 minutes. Quotes may be empty or incomplete.
- Does not scrape NSE's option-chain website.
- Option OI is the current snapshot if returned. It is not presented as intraday OI change.
- Option ATP is shown only as an approximate volume-weighted typical-price proxy if contract intraday candles are returned. Otherwise it says unavailable.
- Entry reference is displayed ask, not a guaranteed fill. SL/targets are illustrative fixed percentage levels.
- No signal is shown if data or confirmation is missing.

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Then open the local URL shown by Streamlit (usually http://localhost:8501).

## Deploy as a URL (free hosting may sleep)
1. Create a GitHub repository and upload `app.py`, `requirements.txt`, and `README.md`.
2. In Streamlit Community Cloud, connect GitHub and choose `app.py` as the app entry point.
3. Deploy. Streamlit will provide a public URL.
4. No API key or broker credentials are required.

Hosting availability and free-tier limits are controlled by the hosting provider. A public URL cannot be created from this package alone; deployment requires your hosting account.

## Important
This is an educational prototype, not a validated trading system or investment advice. Check live quotes in an authorised trading terminal before any trade.
