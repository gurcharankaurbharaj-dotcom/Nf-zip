import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

st.set_page_config(page_title="NIFTY Intraday Signal Desk", page_icon="📈", layout="wide")
IST = ZoneInfo("Asia/Kolkata")

st.title("📈 NIFTY Intraday Signal Desk")
st.caption("Free public data • No broker connection • Signal only • Quotes may be delayed, incomplete or unavailable")

st.warning(
    "Educational decision-support only — not investment advice. Free Yahoo Finance data is not an exchange-grade execution feed. "
    "Verify every quote in your own trading terminal before placing an order. This app never places orders."
)

@st.cache_data(ttl=60, show_spinner=False)
def get_index_data():
    t = yf.Ticker("^NSEI")
    intraday = t.history(period="5d", interval="5m", auto_adjust=False)
    daily = t.history(period="1y", interval="1d", auto_adjust=False)
    return intraday, daily

@st.cache_data(ttl=120, show_spinner=False)
def get_option_chain():
    t = yf.Ticker("^NSEI")
    expiries = list(t.options or [])
    if not expiries:
        return [], None, None
    expiry = expiries[0]
    chain = t.option_chain(expiry)
    return expiries, chain.calls.copy(), chain.puts.copy()

def calc_indicators(df):
    if df is None or df.empty:
        return None
    x = df.copy()
    close = x["Close"].astype(float)
    x["EMA9"] = close.ewm(span=9, adjust=False).mean()
    x["EMA21"] = close.ewm(span=21, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    x["RSI14"] = 100 - (100 / (1 + rs))
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    x["MACD"] = ema12 - ema26
    x["MACD_signal"] = x["MACD"].ewm(span=9, adjust=False).mean()
    vol = x["Volume"].fillna(0).astype(float)
    typical = (x["High"] + x["Low"] + close) / 3
    cumvol = vol.cumsum()
    x["VWAP"] = (typical * vol).cumsum() / cumvol.replace(0, np.nan)
    return x

def nfmt(v, decimals=2):
    try:
        if pd.isna(v) or float(v) == 0:
            return "—"
        return f"{float(v):,.{decimals}f}"
    except Exception:
        return "—"

def num(v):
    try:
        return float(v) if pd.notna(v) else np.nan
    except Exception:
        return np.nan

def build_signal(ind, calls, puts, spot):
    if ind is None or len(ind) < 30:
        return None, "Not enough intraday candles to form a signal."
    last = ind.iloc[-1]
    bullish = (last["Close"] > last["EMA9"] > last["EMA21"] and
               last["MACD"] > last["MACD_signal"] and 52 <= last["RSI14"] <= 75)
    bearish = (last["Close"] < last["EMA9"] < last["EMA21"] and
               last["MACD"] < last["MACD_signal"] and 25 <= last["RSI14"] <= 48)
    side = "CALL" if bullish else ("PUT" if bearish else None)
    if side is None:
        return None, "No aligned EMA / MACD / RSI setup. Wait; do not force a trade."
    chain = calls if side == "CALL" else puts
    if chain is None or chain.empty:
        return None, f"{side} signal found, but the option chain is unavailable."
    c = chain.copy()
    c["strike_gap"] = (pd.to_numeric(c["strike"], errors="coerce") - spot).abs()
    c = c.sort_values("strike_gap")
    # Prefer near-ATM contract with an actual two-sided quote and positive volume/OI.
    c["bid"] = pd.to_numeric(c.get("bid"), errors="coerce")
    c["ask"] = pd.to_numeric(c.get("ask"), errors="coerce")
    c["lastPrice"] = pd.to_numeric(c.get("lastPrice"), errors="coerce")
    c["volume"] = pd.to_numeric(c.get("volume"), errors="coerce")
    c["openInterest"] = pd.to_numeric(c.get("openInterest"), errors="coerce")
    eligible = c[(c["ask"] > 0) & (c["bid"] > 0) & (c["lastPrice"] > 0)]
    if eligible.empty:
        return None, f"{side} trend detected, but no usable two-sided option quote is available."
    row = eligible.iloc[0]
    entry = float(row["ask"])  # conservative buy-side reference, not a guaranteed fill
    bid = float(row["bid"])
    if entry <= 0:
        return None, "No valid ask price; no option entry can be calculated."
    return {
        "direction": side,
        "contract": row.get("contractSymbol", "—"),
        "strike": float(row["strike"]),
        "expiry": str(row.get("lastTradeDate", "")),
        "ltp": num(row["lastPrice"]),
        "bid": bid,
        "ask": entry,
        "oi": num(row.get("openInterest")),
        "volume": num(row.get("volume")),
        "iv": num(row.get("impliedVolatility")),
        "entry": entry,
        "sl": round(entry * 0.80, 2),
        "target1": round(entry * 1.20, 2),
        "target2": round(entry * 1.35, 2),
    }, f"Rule-based {side} trend. Entry reference uses the displayed ask; verify quote freshness and spread."

def get_option_vwap_proxy(contract):
    # Yahoo may not provide intraday candles for NSE index options. Never fabricate ATP.
    try:
        h = yf.Ticker(str(contract)).history(period="1d", interval="1m", auto_adjust=False)
        if h is None or h.empty or "Volume" not in h:
            return None
        vol = pd.to_numeric(h["Volume"], errors="coerce").fillna(0)
        typical = (h["High"] + h["Low"] + h["Close"]) / 3
        total = vol.sum()
        if total <= 0:
            return None
        return float((typical * vol).sum() / total)
    except Exception:
        return None

col1, col2, col3 = st.columns([1,1,1])
with col1:
    refresh = st.button("🔄 Refresh data", type="primary", use_container_width=True)
with col2:
    st.metric("Data mode", "Free / delayed")
with col3:
    st.metric("Broker connection", "None")

if refresh:
    st.cache_data.clear()

with st.spinner("Fetching available public NIFTY data…"):
    try:
        intraday, daily = get_index_data()
        expiries, calls, puts = get_option_chain()
    except Exception as e:
        st.error(f"Data provider did not return data: {e}")
        intraday, daily, expiries, calls, puts = pd.DataFrame(), pd.DataFrame(), [], None, None

ind = calc_indicators(intraday) if intraday is not None and not intraday.empty else None
if ind is not None:
    latest = ind.iloc[-1]
    spot = num(latest["Close"])
    stamp = ind.index[-1]
    try:
        stamp_text = stamp.tz_convert(IST).strftime("%d %b %Y, %I:%M:%S %p IST") if stamp.tzinfo else stamp.strftime("%d %b %Y, %I:%M:%S")
    except Exception:
        stamp_text = str(stamp)
    a,b,c,d = st.columns(4)
    a.metric("NIFTY last available close", nfmt(spot))
    b.metric("EMA 9 / EMA 21", f"{nfmt(latest['EMA9'])} / {nfmt(latest['EMA21'])}")
    c.metric("RSI (14)", nfmt(latest["RSI14"]))
    d.metric("VWAP (index proxy)", nfmt(latest["VWAP"]))
    st.caption(f"Latest candle timestamp returned by provider: {stamp_text}. This timestamp is not a guarantee of real-time data.")
else:
    spot = np.nan
    st.error("NIFTY intraday candles are unavailable right now. Indicators and signals are disabled rather than estimated.")

if ind is not None:
    with st.expander("NIFTY intraday candles and indicators", expanded=False):
        view = ind[["Open","High","Low","Close","Volume","EMA9","EMA21","RSI14","MACD","MACD_signal","VWAP"]].tail(50)
        st.line_chart(view[["Close","EMA9","EMA21","VWAP"]])
        st.dataframe(view.sort_index(ascending=False), use_container_width=True)

st.subheader("Option chain — nearest available expiry")
if expiries and calls is not None and puts is not None:
    expiry = st.selectbox("Expiry", expiries, index=0)
    # fetch selected expiry if user changes from nearest
    if expiry != expiries[0]:
        try:
            selected = yf.Ticker("^NSEI").option_chain(expiry)
            calls, puts = selected.calls.copy(), selected.puts.copy()
        except Exception:
            calls, puts = pd.DataFrame(), pd.DataFrame()
    if not calls.empty and not puts.empty:
        strike_col = "strike"
        strikes = sorted(set(pd.to_numeric(calls[strike_col], errors="coerce").dropna()).union(
                           set(pd.to_numeric(puts[strike_col], errors="coerce").dropna())))
        if np.isfinite(spot) and strikes:
            near = min(strikes, key=lambda z: abs(z-spot))
            default_idx = strikes.index(near)
        else:
            default_idx = 0
        selected_strike = st.selectbox("Strike for contract detail", strikes, index=default_idx)
        def side_row(df, strike):
            x = df[pd.to_numeric(df["strike"], errors="coerce") == float(strike)]
            return x.iloc[0] if not x.empty else None
        cr = side_row(calls, selected_strike)
        pr = side_row(puts, selected_strike)
        rows=[]
        for label, r in [("CALL",cr),("PUT",pr)]:
            if r is not None:
                rows.append({
                    "Side":label, "Contract":r.get("contractSymbol","—"), "Strike":r.get("strike"),
                    "LTP":r.get("lastPrice"), "Bid":r.get("bid"), "Ask":r.get("ask"),
                    "Volume":r.get("volume"), "OI":r.get("openInterest"), "IV":r.get("impliedVolatility")
                })
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        # OI snapshot history is held only for this browser session; this is not exchange OI change.
        if "oi_snap" not in st.session_state:
            st.session_state.oi_snap = {}
        for label, df in [("CALL",calls),("PUT",puts)]:
            for _, r in df.iterrows():
                key = (expiry, label, float(r["strike"]))
                current_oi = num(r.get("openInterest"))
                previous = st.session_state.oi_snap.get(key)
                if np.isfinite(current_oi):
                    st.session_state.oi_snap[key] = current_oi
        st.caption("OI change: this public snapshot may show current OI only. The app does not label day-on-day OI as intraday change. Refresh-to-refresh comparison is session-local and is not an exchange-certified OI delta.")
        chain_view = pd.concat([
            calls.assign(Side="CALL"), puts.assign(Side="PUT")
        ], ignore_index=True)
        cols = [x for x in ["Side","strike","lastPrice","bid","ask","volume","openInterest","impliedVolatility"] if x in chain_view.columns]
        st.dataframe(chain_view[cols].sort_values(["strike","Side"]), use_container_width=True, hide_index=True)
    else:
        st.info("The provider returned no usable calls/puts for the selected expiry.")
else:
    st.info("Yahoo Finance did not return an NIFTY options chain at this time. The app will not invent OI, premiums, bid/ask or an option trade.")

st.subheader("Intraday signal and option levels")
signal, reason = build_signal(ind, calls, puts, spot) if ind is not None and np.isfinite(spot) else (None, "Waiting for valid NIFTY candles.")
st.write(reason)
if signal:
    x1,x2,x3 = st.columns(3)
    x1.metric("Directional bias", signal["direction"])
    x2.metric("Selected contract", signal["contract"])
    x3.metric("Strike", nfmt(signal["strike"],0))
    x1,x2,x3,x4 = st.columns(4)
    x1.metric("LTP", nfmt(signal["ltp"]))
    x2.metric("Bid", nfmt(signal["bid"]))
    x3.metric("Ask / entry reference", nfmt(signal["ask"]))
    x4.metric("OI / volume", f"{nfmt(signal['oi'],0)} / {nfmt(signal['volume'],0)}")
    atp = get_option_vwap_proxy(signal["contract"])
    y1,y2,y3,y4 = st.columns(4)
    y1.metric("Option ATP / VWAP proxy", nfmt(atp) if atp is not None else "Unavailable")
    y2.metric("Stop loss (−20%)", f"₹{signal['sl']:.2f}")
    y3.metric("Target 1 (+20%)", f"₹{signal['target1']:.2f}")
    y4.metric("Target 2 (+35%)", f"₹{signal['target2']:.2f}")
    st.caption("Entry is the displayed ask, not a guaranteed execution price. The option ATP field is only a volume-weighted typical-price proxy when intraday contract candles exist; otherwise it is unavailable. SL/targets are illustrative fixed-percentage levels, not validated strategy outputs.")
else:
    st.info("No trade setup. A blank signal is intentional when trend confirmation or a usable option quote is missing.")

st.subheader("Daily market context")
if daily is not None and not daily.empty:
    d = daily.copy()
    d["SMA20"] = d["Close"].rolling(20).mean()
    d["SMA50"] = d["Close"].rolling(50).mean()
    lastd = d.iloc[-1]
    q1,q2,q3 = st.columns(3)
    q1.metric("Latest daily close", nfmt(lastd["Close"]))
    q2.metric("20-day SMA", nfmt(lastd["SMA20"]))
    q3.metric("50-day SMA", nfmt(lastd["SMA50"]))
    st.line_chart(d[["Close","SMA20","SMA50"]].tail(120))
else:
    st.info("Daily history unavailable.")

st.divider()
st.caption(
    "Data source: Yahoo Finance public endpoints via yfinance. Availability, timestamps, bid/ask, option-chain coverage and refresh limits are controlled by the provider. "
    "No NSE scraping, no broker integration, no order routing. Verify with an authorised market-data source before trading."
)
st.caption("Risk note: Options can lose the entire premium. Do not trade solely from this dashboard. Check expiry, lot size, liquidity, spread, circuit limits and event risk.")
